import streamlit as st,requests
st.title("Estimation du modèle choisi")
st.sidebar.title(st.session_state['titre'])

for i in st.session_state['df'].columns:
    st.session_state['values'][i] = st.sidebar.selectbox(i, st.session_state['df'][i])
if st.sidebar.button(st.session_state['button']):
    data = requests.get("http://localhost:5000/modelApi", params=st.session_state['values']).json()
    st.session_state['output_query']= data
    st.sidebar.header(st.session_state["Query Response"])
    st.sidebar.write( st.session_state['output_query'])